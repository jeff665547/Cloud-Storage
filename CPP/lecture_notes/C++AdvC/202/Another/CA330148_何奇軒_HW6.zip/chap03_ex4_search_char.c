# include <stdio.h>
# include <string.h>

void print(char arr[][128], int len){
    int i;
    for(i = 0; i < len; i++){
        printf("%s ", arr[i]);
    }
    printf("\n");
}

void insert_sort(char arr[][128], int len){
    int i, j;
    char key[128];
    for(i = 1; i < len; i++){
        strcpy(key, arr[i]);
        for(j = i - 1; j >= 0 && (strcmp(arr[j], key) > 0); j--){
            strcpy(arr[j+1], arr[j]);
        }
        if(strcmp(arr[j+1], key)){
            strcpy(arr[j+1], key);
        }
    }
}

void linear_search(char arr[][128], int len, char input[]){
    int i;
    for(i = 0; i < len; i++){
        printf("%d: %s\n", i, arr[i]);
        if(!strcmp(arr[i], input)){
            printf("found %s\n", input);
            return ;
        }
    }
    printf("not found\n");
    return;
}

void binary_search(char arr[][128], int len, char input[]){
    int low, med, high;
    high = len;
    low = 0;

    while(low <= high){
        med = (low + high)/2;
        printf("%d: %s\n", med, arr[med]);

        if(strcmp(input, arr[med]) == 0){
            printf("found %s\n", input);
            return;
        }else if(strcmp(input, arr[med]) > 0){
            low = med + 1;

        }else if(strcmp(input, arr[med]) < 0){
            high = med - 1;
        }
    }
    printf("not found\n");
    return;
}

int main(){

    char ary[10][128];
    int op;
    char input[128];
    int ct = 0;
    
    while(1){
        scanf("%d", &op);

        switch(op){
            case 1:
                scanf("%s", &input);
                strcpy(ary[ct], input);
                ct++;
                insert_sort(ary, ct);
                break;

            case 2:
                // insert_sort(ary, ct);
                scanf("%s", &input);
                linear_search(ary, ct, input);
                break;

            case 3:
                // insert_sort(ary, ct);
                scanf("%s", &input);
                binary_search(ary, ct, input);
                break;

            case 4:
                // insert_sort(ary, ct);
                print(ary, ct);
                break;

            case 5:
                return 0;
        }
    }

    return 0;
}