f1 = open("text.txt", "r")
txt1 = f1.readlines()
fl.close()











